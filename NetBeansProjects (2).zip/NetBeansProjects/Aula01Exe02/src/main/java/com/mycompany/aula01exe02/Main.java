
package com.mycompany.aula01exe02;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        
        // Declaração de variaveis
        int qtdHrs;
        float salBruto, valorHora;
        
        //Criação de um recurso do tipo teclado
        Scanner teclado = new Scanner(System.in);
        
        //Recebendo os dados do usuário
        System.out.println("Digite o valor hora: ");
        valorHora = teclado.nextFloat();
        
        //Rcebendo os dados da quantidade de horas        
        System.out.println("Digite a quantidade de horas trabalhadas: ");
        qtdHrs = teclado.nextInt();
        
        //Calculando o salario bruto        
        salBruto = qtdHrs * valorHora;
        
        //Exibindo o salário calculado
        System.out.println("Salário = " + salBruto);        
        
    }
}
