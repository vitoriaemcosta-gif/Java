
package com.mycompany.aula01exe03;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        
        int q1, q2, q3, q4, q5, q6;
        double d;
        double r;
        
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Digite a quantidade de moedar de U$1,00: ");
        q1 = teclado.nextInt();
        
        System.out.println("Digite a quantidade de moedar de U$0,50: ");
        q2 = teclado.nextInt();
        
        System.out.println("Digite a quantidade de moedar de U$0,25: ");
        q3 = teclado.nextInt();
        
        System.out.println("Digite a quantidade de moedar de U$0,10: ");
        q4 = teclado.nextInt();
        
        System.out.println("Digite a quantidade de moedar de U$0,05: ");
        q5 = teclado.nextInt();
        
        System.out.println("Digite a quantidade de moedar de U$0,01: ");
        q6 = teclado.nextInt();
        
        System.out.println("Digite a cotação do dolar: ");
        d = teclado.nextDouble();
        
        r = (q1 + 0.5*q2 + 0.25*q3 + 0.1*q4 + 0.05*q5 + 0.01*q6)*d;
        
        System.out.println("O valor eh: " + r);
        
    }
    
}
