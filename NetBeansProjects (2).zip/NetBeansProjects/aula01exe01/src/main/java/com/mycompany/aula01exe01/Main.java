
package com.mycompany.aula01exe01;

public class Main {
    public static void main(String[] args) {
        System.out.println("Primeira aula de Java");
    }
}
