/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.a03ex03;

/**
 *
 * @author unifvcosta
 */
public class TesteRetangulo {
    public static void main(String[] args) {
            Retangulo r = new Retangulo(2,4,4,4,2,2,4,2);
            Retangulo r2 = new Retangulo(-2,4,4,4,2,2,4,2);
            
            r.mostraDados();
            System.out.println("Perimetro r1:" + r.perimetro());
            System.out.println("Area r1:" + r.area());
            System.out.println("Comprimento r1:" + r.comprimento());
            System.out.println("Largura r1:" + r.largura());
            
            r2.mostraDados();
            System.out.println("Perimetro r2:" + r2.perimetro());
            System.out.println("Area r2:" + r2.area());
            System.out.println("Comprimento r2:" + r2.comprimento());
            System.out.println("Largura r2:" + r2.largura());
            
            
            
    }
    
}
