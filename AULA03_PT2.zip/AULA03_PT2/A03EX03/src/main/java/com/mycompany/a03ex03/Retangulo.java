/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.a03ex03;

/**
 *
 * @author unifvcosta
 */
public class Retangulo {
    
    private double x1, y1;
    private double x2, y2;
    private double x3, y3;
    private double x4, y4;
    
    
   public Retangulo(double x1, double y1, 
                    double x2, double y2, 
                    double x3, double y3, 
                    double x4, double y4){
       
       set(x1, y1, x2, y2, x3, y3, x4, y4);
       
   }
   
   public void set(double x1, double y1, 
                    double x2, double y2, 
                    double x3, double y3, 
                    double x4, double y4){
       //verificar se os valores estao dentro do limite definido(>=0 && >=20)
       if(x1<00 || x1>20 ||
          x2<00 || x2>20 ||
          x3<00 || x3>20 ||
          x4<00 || x4>20 ||
          y1<00 || y1>20 ||
          y2<00 || y2>20 ||
          y3<00 || y3>20 ||
          y4<00 || y4>20 ){
           
          System.out.println("Coordenadas Invalidas!");
          return;
       }
       
       //verificando se os pontos formam um retangulo
       if(y1 != y2 ||
          y3 != y4 ||
          x1 != x3 ||
          x2 != x4){
           System.out.println("Os pontos não formam um retangulo!");
           return;
       }
       
       this.x1 = x1;
       this.x2 = x2;
       this.x3 = x3;
       this.x4 = x4;
       this.y1 = y1;
       this.y2 = y2;
       this.y3 = y3;
       this.y4 = y4;
   }
   
   public double comprimento(){
       double horizontal = Math.abs(x2 - x1);
       double vertical = Math.abs(y4 - y1);
       
       if(horizontal > vertical){
           return horizontal;
       }
       else{
           return vertical;
       }      
   }
   
   public double largura(){
       double horizontal = Math.abs(x2 - x1);
       double vertical = Math.abs(y4 - y1);
       
       if(horizontal < vertical){
           return horizontal;
       }
       else{
           return vertical;
       }      
   }
    
  public double area(){
      return largura()*comprimento();
  }
  
  public double perimetro(){
      return 2*largura()+2*comprimento();
  }
  
  public void mostraDados(){
      System.out.println("X1: "+ x1 + ", Y1 "+ y1);
      System.out.println("X2: "+ x2 + ", Y2 "+ y2);
      System.out.println("X3: "+ x3 + ", Y3 "+ y3);
      System.out.println("X4: "+ x4 + ", Y4 "+ y4);    
  }
  
}
