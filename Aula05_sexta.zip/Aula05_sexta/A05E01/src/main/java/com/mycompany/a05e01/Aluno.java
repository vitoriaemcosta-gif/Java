/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.a05e01;

/**
 *
 * @author unifvcosta
 */
public class Aluno extends Pessoa{
    private String curso;
    
    public Aluno(){
        
    }
    
    public Aluno(String curso, String nome, String sobrenome, int idade) {
        super(nome, sobrenome, idade);
        this.curso = curso;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }
    
    public void print(){
        System.out.println("---- EXIBE DADOS ----");
        System.out.println("Nome" + nome);
        System.out.println("Sobrenome" + sobrenome);
        System.out.println("Curso" + curso);
        System.out.println("Idade" + idade);

        
    }
    
    
    
}
