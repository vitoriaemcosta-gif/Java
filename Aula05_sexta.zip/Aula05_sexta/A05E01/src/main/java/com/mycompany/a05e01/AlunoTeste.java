/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.a05e01;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author unifvcosta
 */
public class AlunoTeste {
    public static void main(String[] args) {
        Scanner teclado  = new Scanner(System.in);
        
        ArrayList<Aluno> turma = new ArrayList<>();
        
        String nomeLocal, sobrenomeLocal, cursoLocal;
        
        int idadeLocal;
        
        turma.add(new Aluno());
        
        System.out.println("Informe o nome:");
        nomeLocal = teclado.nextLine();
        System.out.println("Informe o sobrenome:");
        sobrenomeLocal = teclado.nextLine();
        System.out.println("Informe o curso:");
        cursoLocal = teclado.nextLine();
        System.out.println("Informe a idade:");
        idadeLocal = teclado.nextInt();
        turma.add(new Aluno(cursoLocal, nomeLocal, sobrenomeLocal, idadeLocal));
        
        for(Aluno a: turma){
            a.print();
        
        }
    }
}
