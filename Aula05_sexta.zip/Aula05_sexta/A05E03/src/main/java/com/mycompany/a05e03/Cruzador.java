/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.a05e03;

/**
 *
 * @author unifvcosta
 */
public class Cruzador extends NavioDeGuerra {
    protected int numCanhoes;
    
    public Cruzador(){
    }

    public Cruzador(int numCanhoes) {
        this.numCanhoes = numCanhoes;
    }

    public Cruzador(int numCanhoes, float blindagem, float ataque) {
        super(blindagem, ataque);
        this.numCanhoes = numCanhoes;
    }

    public Cruzador(int numCanhoes, float blindagem, float ataque, 
            int numTripulantes, String nome) {
        super(blindagem, ataque, numTripulantes, nome);
        this.numCanhoes = numCanhoes;
    }

    public int getNumCanhoes() {
        return numCanhoes;
    }

    public void setNumCanhoes(int numCanhoes) {
        this.numCanhoes = numCanhoes;
    }

    @Override
    public String toString() {
        return "Cruzador{" + "numCanhoes=" + numCanhoes + '}';
    }
    
    //reescrevendo as funções
    @Override
    public void poderDeFogo(){
        System.out.println("Poder de Fogo: " + (ataque * Math.sqrt(numCanhoes)));
    }
    
}
