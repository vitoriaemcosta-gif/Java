/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.a05e03;

/**
 *
 * @author unifvcosta
 */
public class PortaAvioes extends NavioDeGuerra {
    protected int numAvioes;
    
    public PortaAvioes(){
        
    }

    public PortaAvioes(int numAvioes) {
        this.numAvioes = numAvioes;
    }

    public PortaAvioes(int numAvioes, float blindagem, float ataque) {
        super(blindagem, ataque);
        this.numAvioes = numAvioes;
    }

    public PortaAvioes(int numAvioes, float blindagem, float ataque, 
            int numTripulantes, String nome) {
        super(blindagem, ataque, numTripulantes, nome);
        this.numAvioes = numAvioes;
    }

    public int getNumAvioes() {
        return numAvioes;
    }

    public void setNumAvioes(int numAvioes) {
        this.numAvioes = numAvioes;
    }

    @Override
    public String toString() {
        return "PortaAvioes{" + "numAvioes=" + numAvioes + '}';
    }
    
    @Override
    public void poderDeFogo(){
        System.out.println("Poder de Fogo: " + (ataque * (numAvioes*numAvioes)));
    }
    
}
