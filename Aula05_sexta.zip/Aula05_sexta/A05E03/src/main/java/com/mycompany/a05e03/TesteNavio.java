/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.a05e03;

/**
 *
 * @author unifvcosta
 */
public class TesteNavio {
    public static void main(String[] args) {
        
        // Instanciando o cruzador
        Cruzador cruzador = new Cruzador(6, 500.0f, 80.0f, 120, 
                "Navio Cruzador Valente");
        
        // Instanciando o um porta-aviões
        PortaAvioes portaAvioes = new PortaAvioes(10, 800.0f, 100.0f, 300, 
                "Porta-Aviões Soberano");
        
        //Instanciando um Navio Mercante 
        NavioMercante mercante = new NavioMercante(1500.0f, 00.0f, 40, 
                "Cargueiro Horizonte");
        
        System.out.println("TESTE CRUZADOR");
        cruzador.exibirArmas();
        
        System.out.println("TESTE PORTA-AVIOES");
        portaAvioes.exibirArmas();
        
        System.out.println("TESTE NAVIO MERCANTE");
        mercante.carregamento();
    }
}
