/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.a05e03;

/**
 *
 * @author unifvcosta
 */
public class NavioMercante extends Navio{
    protected float capacidadeCarga;
    protected float carga;
    
    public NavioMercante(){
    }

    public NavioMercante(float capacidadeCarga, float carga) {
        this.capacidadeCarga = capacidadeCarga;
        this.carga = carga;
    }

    public NavioMercante(float capacidadeCarga, float carga, int numTripulantes, String nome) {
        super(numTripulantes, nome);
        this.capacidadeCarga = capacidadeCarga;
        this.carga = carga;
    }

    public float getCapacidadeCarga() {
        return capacidadeCarga;
    }

    public void setCapacidadeCarga(float capacidadeCarga) {
        this.capacidadeCarga = capacidadeCarga;
    }

    public float getCarga() {
        return carga;
    }

    public void setCarga(float carga) {
        this.carga = carga;
    }

    @Override
    public String toString() {
        return "NavioMercante{" + "capacidadeCarga=" + capacidadeCarga + 
                ", carga=" + carga + '}';
    }
    
    public void carregamento(){
        System.out.println("---- CARREGAMENTO ----");
        System.out.println("Nome:......" + getNome());
        System.out.println("numTripulantes:......" + getNumTripulantes());
        System.out.println("Volume:......." + carga/capacidadeCarga);
    }
}
