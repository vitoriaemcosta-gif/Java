/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.a05e03;

/**
 *
 * @author unifvcosta
 */
public class NavioDeGuerra extends Navio {
    protected float blindagem;
    protected float ataque;
    
    public NavioDeGuerra(){
    }

    public NavioDeGuerra(float blindagem, float ataque) {
        this.blindagem = blindagem;
        this.ataque = ataque;
    }

    public NavioDeGuerra(float blindagem, float ataque, 
            int numTripulantes, String nome) {
        super(numTripulantes, nome);
        this.blindagem = blindagem;
        this.ataque = ataque;
    }
    
    public void exibirArmas(){
        System.out.println("---- ARMAS ----");
        System.out.println("Nome:......" + getNome());
        System.out.println("numTripulantes:......" + getNumTripulantes());
        System.out.println("Blindagem:......" + blindagem);
        this.poderDeFogo();
    }
    
    public void poderDeFogo(){
        System.out.println("Poder de Fogo: " + ataque);
    }

    public float getBlindagem() {
        return blindagem;
    }

    public float getAtaque() {
        return ataque;
    }

    public void setBlindagem(float blindagem) {
        this.blindagem = blindagem;
    }

    public void setAtaque(float ataque) {
        this.ataque = ataque;
    }

    @Override
    public String toString() {
        return "NavioDeGuerra{" + "blindagem=" + blindagem + ", "
                + "ataque=" + ataque + '}';
    }
           
}
