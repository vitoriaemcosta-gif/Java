/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.a05e03;

/**
 *
 * @author unifvcosta
 */
public class Navio {
    protected int numTripulantes;
    protected String nome;
    
    public Navio(){
    }

    public Navio(int numTripulantes, String nome) {
        this.numTripulantes = numTripulantes;
        this.nome = nome;
    }

    public int getNumTripulantes() {
        return numTripulantes;
    }

    public void setNumTripulantes(int numTripulantes) {
        this.numTripulantes = numTripulantes;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    @Override
    public String toString() {
        return "Navio{" + "numTripulantes=" + numTripulantes + 
                ", nome=" + nome + '}';
    }
    
    public void exibirInfoGeral(){
        
    }
    
}
