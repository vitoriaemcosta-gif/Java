/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.a05e02;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author unifvcosta
 */
public class PoliticoTeste {
    
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        
        ArrayList<Vereador> vereadores = new ArrayList<>();
        ArrayList<Prefeito> prefeitos = new ArrayList<>();
        
        String nomeL, partidoL, estadoL, municipioL;
        
        System.out.println("--- ENTRADA DE DADOS DE PREFEITOS: ");
        System.out.println("Informe o nome:");
        nomeL = teclado.nextLine();
        System.out.println("Informe o partido:");
        partidoL = teclado.nextLine();
        System.out.println("Informe o estado:");
        estadoL = teclado.nextLine();
        System.out.println("Informe o municipio:");
        municipioL = teclado.nextLine();
        prefeitos.add(new Prefeito(nomeL, partidoL, estadoL, municipioL));
        
        System.out.println("--- ENTRADA DE DADOS DE VEREADORES: ");
        System.out.println("Informe o nome:");
        nomeL = teclado.nextLine();
        System.out.println("Informe o partido:");
        partidoL = teclado.nextLine();
        System.out.println("Informe o estado:");
        estadoL = teclado.nextLine();
        System.out.println("Informe o municipio:");
        municipioL = teclado.nextLine();
        vereadores.add(new Vereador(nomeL, partidoL, estadoL, municipioL));
        
        for(Prefeito p: prefeitos){
            p.apresentacao();
        }
        
        for(Vereador v: vereadores){
            v.apresentacao();
        }
    }
    
}
