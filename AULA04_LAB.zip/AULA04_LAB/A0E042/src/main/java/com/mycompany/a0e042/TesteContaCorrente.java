/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.a0e042;

import java.util.ArrayList;
import java.util.Scanner;

public class TesteContaCorrente {
    public static void main(String[] args) {
        
        ArrayList<ContaCorrente> contas = new ArrayList<>();
        
        Scanner teclado = new Scanner(System.in);
        
        double saldoLocal, valorLocal;
        String escolha;
        
        System.out.println("Criando as contas");
        
        for(int i = 0; i<3; i++){
            System.out.println("Informe o saldo atual da conta nro "+ (i+1) 
                    +":");
            saldoLocal = teclado.nextDouble();
            contas.add(new ContaCorrente(saldoLocal));          
        }
        
        System.out.println("Saldo das contas após a criação:");
        for(int i = 0; i<contas.size(); i++){
            System.out.println(contas.get(i));
        }
        
        System.out.println("Realizado saques e depositos");
        for(int i = 0; i<contas.size(); i++){
            
            teclado.nextLine();
            System.out.println("Digite SAQUE ou DEPOSITO: ");
            escolha = teclado.nextLine();
            System.out.println("Informe o valor: ");
            valorLocal = teclado.nextDouble();
            if(escolha.equalsIgnoreCase("saque")){
                contas.get(i).sacar(valorLocal);
            } else{
                contas.get(i).depositar(valorLocal);
            }
        }
        
        System.out.println("Saldo das contas após movimentação: ");
        for(int i = 0; i < contas.size(); i++){
            System.out.println(contas.get(i));
        
        }
    }
    
}
