/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.a0e042;

/**
 *
 * @author unifvcosta
 */
public class ContaCorrente {
    private double saldo = 0;

    public ContaCorrente(double saldo){
        this.saldo = saldo;
    }
    
    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
    
    // méteodo depositar
    public void depositar(double valor){
        this.saldo += valor;
    }
    
    // méteodo ssacar
    public void sacar(double valor){
        this.saldo -= valor;
    }

    @Override
    public String toString() {
        return "ContaCorrente{" + "saldo=" + saldo + '}';
    }
    
    
}
