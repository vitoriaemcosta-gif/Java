
package com.mycompany.a04e01;

public class TesteLaser {
    
    public static void main(String[] args) {
        Laser l[] = new Laser[10];
        
        for(int i = 0; i < 10; i++){
            l[i] = new Laser("KingLing", i+1, i*10, 50/(i+1));            
        }
        
        /*
        for(int i = 0; i < 10; i++){
            System.out.println("-----------" + i + "------------");
            System.out.println("Fabrincante: " + l[i].getFabricante());
            System.out.println("Alcance: " + l[i].getAlcance());
            System.out.println("Precisão: " + l[i].getPrecisao());
            System.out.println("Mdida: " + l[i].getMedida());
        }*/
        
        for(int i = 0; i<10; i++){
            System.out.println("------------[" + i + "]------------" );
            
            System.out.println(l[i]);
        
        
        }
    }
}
