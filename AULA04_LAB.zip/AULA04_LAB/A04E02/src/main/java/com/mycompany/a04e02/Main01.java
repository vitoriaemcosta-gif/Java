/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.a04e02;

import java.util.ArrayList;

public class Main01 {
    
    public static void main(String[] args) {
        
        ArrayList <String> cores1 = new ArrayList<>();
               
        cores1.add("Azul");
        cores1.add("Verde");
        cores1.add("Roxo");
        
        ArrayList <String> cores2 = new ArrayList<>();
        
        cores2.add("Azul");
        cores2.add("Preto");
        cores2.add("Verde");
        
        
        for(int i = 0; i <cores1.size(); i++){
            if(cores1.contains(cores2.get(i))){
                System.out.println("Cores iguais: " + cores2.get(i));
            }
        }
    }  
    
}
