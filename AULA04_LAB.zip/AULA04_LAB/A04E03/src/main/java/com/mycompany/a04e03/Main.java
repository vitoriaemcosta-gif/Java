/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.a04e03;

import java.util.ArrayList;

/**
 *
 * @author unifvcosta
 */
public class Main {
    public static void main(String[] args) {
        ArrayList<String> nomes1 = new ArrayList<>();
        
        nomes1.add("Vitoria");
        nomes1.add("Eutalia");
        nomes1.add("Francisco");
        
        //ArrayList<String> nomes2 = new ArrayList<>();
        
        // passa o ArrayList a ser copiado no construtor do novo ArrayList
        ArrayList<String> nomes2 = new ArrayList<>(nomes1);
        
        // não funciona como cópia
        //nomes2 = nomes1;
        
        nomes1.set(0, "Gaby");
        
        System.out.println("Nomes 1:" + nomes1);
        System.out.println("Nomes 2:" + nomes2);
    }
}
