/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.a2e02;

import java.util.Scanner;

/**
 *
 * @author unifvcosta
 */
public class TesteSwapper {
     
    public static void main(String[] args) {
        
        //declarar variaveis locais
        float yLocal;
        float xLocal;
        
        Scanner teclado = new Scanner(System.in);
        
        Swapper troca = new Swapper();
        
        System.out.println("Digite o valor de Y: ");
        yLocal = teclado.nextFloat();
        troca.setY(yLocal);
        
        System.out.println("Digite o valor de X: ");
        xLocal = teclado.nextFloat();
        troca.setX(xLocal);
        
        troca.swap();
        
        System.out.println("X: " + troca.getX());
        System.out.println("Y: " + troca.getY());
        
    }
}
    

