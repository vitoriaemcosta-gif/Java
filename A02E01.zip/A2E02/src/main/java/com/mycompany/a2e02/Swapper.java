package com.mycompany.a2e02;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author unifvcosta
 */
public class Swapper {
    private float y,x;
    
    
    //get (obter os valores dos atributos)
    public float getY(){
        return y;
    }
    public float getX(){
        return x;
    }
    
    //set (atribuir valores para os atributos)
    public void setY(float y){
        this.y = y;
    }
    
    public void setX(float x){
        this.x = x;
    }
    
    public void swap(){
    float troca = x;
    x = y;
    y = troca;
    }
    
}
