/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package a04e01;

/**
 *
 * @author unifvcosta
 */
public class TesteUml {
    
    public static void main(String[] args) {
        
    //String nome, String departamento
    Professor prof = new Professor("Gabriela", "CC");
    //String nome, String codigo, Professor professor
    Disciplina disc = new Disciplina("OO", "CCM310", prof);
    //String nome, String ra, String curso, Disciplina disciplina
    Aluno aluno01 = new Aluno("Vinicius","222", "CC", disc); 
        
    System.out.println(aluno01.toString());
    
    System.out.println(aluno01.getNome());
    
    System.out.println(aluno01.getDisciplina().getCodigo());
  
    }
       
}
