/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package a04e01;

/**
 *
 * @author unifvcosta
 */
public class Aluno {
    private String nome, ra, curso;
    private Disciplina disciplina;

    public Aluno(String nome, String ra, String curso, Disciplina disciplina) {
        this.nome = nome;
        this.ra = ra;
        this.curso = curso;
        this.disciplina = disciplina;
    }

    @Override
    public String toString() {
        return "Aluno{" + "nome=" + nome + ", ra=" + ra + ", curso=" + curso + ", disciplina=" + disciplina + '}';
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getRa() {
        return ra;
    }

    public void setRa(String ra) {
        this.ra = ra;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    public Disciplina getDisciplina() {
        return disciplina;
    }

    public void setDisciplina(Disciplina disciplina) {
        this.disciplina = disciplina;
    }

    
    
    
    
    
}
