/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package a04e06;

import java.util.ArrayList;

/**
 *
 * @author unifvcosta
 */
public class TesteEstudante {
    public static void main(String[] args) {
        
        
        ArrayList<Estudante> estudantes = new ArrayList<>();
        /*
        Estudante estudante1 = new Estudante("Vinicius", "Santos");
        Estudante estudante2 = new Estudante("Vinicius", "Souza");
        
        System.out.println(estudante1);
        System.out.println(estudante2);
        System.out.println(estudante2.getProximoId());
        */
        
        for(int i=0; i<30; i++){
            estudantes.add(new Estudante ("Vinicius", "Santos"));
        }
        
        for(Estudante estudante: estudantes){
            System.out.println(estudante);
        }
        
        for(int i=0; i<30; i++){
            System.out.println(estudantes.get(i));
            System.out.println(estudantes.get(i).getNome());
        }
        
    }
    
}
