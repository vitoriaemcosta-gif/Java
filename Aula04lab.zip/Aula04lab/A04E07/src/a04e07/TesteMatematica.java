/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package a04e07;

/**
 *
 * @author unifvcosta
 */
public class TesteMatematica {
    
    public static void main(String[] args) {
        Matematica mat = new Matematica();
        
        int maior = Matematica.max3(3, 2, 1);
        System.out.println(maior);
        
        System.out.println(Matematica.impar(true, true, true));
        System.out.println(Matematica.impar(true, false, true));
        System.out.println(Matematica.impar(false, false, true));
        
        System.out.println(Matematica.maioria(true, true, true));
        System.out.println(Matematica.maioria(true, false, true));
        System.out.println(Matematica.maioria(false, false, true));
        System.out.println(Matematica.maioria(false, false, false));
    }
    
}
