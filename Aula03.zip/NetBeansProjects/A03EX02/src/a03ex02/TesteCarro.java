/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package a03ex02;

/**
 *
 * @author unifvcosta
 */
public class TesteCarro {
    
    public static void main(String[] args) {
        Carro car01 = new Carro();
        Carro car02 = new Carro("Fusca", "Vermelho");
        Carro car03 = new Carro("Corsa", "Prata", 2004, 19800, 200.000);
        
        System.out.printf("Carro 01 - Modelo:%s, Cor:%s, Ano:%d, Preco:%.2f, Km:%.2f\n",
                car01.getModelo(), car01.getCor(), car01.getAno(), car01.getPreco(), car01.getKm());
        
        System.out.printf("Carro 01 - Modelo:%s, Cor:%s, Ano:%d, Preco:%.2f, Km:%.2f\n",
        car02.getModelo(), car02.getCor(), car02.getAno(), car02.getPreco(), car02.getKm());
        
        System.out.printf("Carro 03 - Modelo:%s, Cor:%s, Ano:%d, Preco:%.2f, Km:%.2f\n",
        car03.getModelo(), car03.getCor(), car03.getAno(), car03.getPreco(), car03.getKm());
        
    }
    
}
