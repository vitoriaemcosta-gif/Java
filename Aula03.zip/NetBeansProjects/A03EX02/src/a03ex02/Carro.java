/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package a03ex02;

/**
 *
 * @author unifvcosta
 */
public class Carro {
    private String modelo;
    private String cor;
    private int ano;
    private double preco;
    private double km;
   
    //construtor
    
    public Carro(){
        
    }
    
    public Carro(String modelo,String cor){
        this.modelo = modelo;
        this.cor =  cor;
    }
    
    public Carro(String modelo,String cor, int ano, double preco, double km){
        this.modelo = modelo;
        this.cor =  cor;
        this.setAno(ano);
        this.setPreco(preco);
        this.setKm(km);            
       
    }
    
    public void setAno(int ano){
        this.ano = (ano > 1920 && ano<2026) ? ano : 0;
    }
    
    public void setPreco(double preco){
        this.preco = (preco > 1000) ? preco : 0;
    }
    
    public void setKm(double km){
        this.km = (km > 0 && km<400) ? km : 0;
    }
    
    public String getModelo(){
        return modelo;
    }
    
    public String getCor(){
        return cor;
    }
    
    public int getAno(){
        return ano;
    }
    
    public double getPreco(){
        return preco;
    }
    
    public double getKm(){
        return km;
    }
}
