/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package a03e01;

/**
 *
 * @author unifvcosta
 */
public class Funcionario {
    
    private String nome, sobrenome, sexo;
    private int idade, numero;
    private double salarioMensal; 
    
    // construtor
    
    public Funcionario(){
        
    }
    
    public Funcionario(String nome, String sobrenome, String sexo, int idade, int numero, double salarioMensal){
        this.nome = nome;
        this.sobrenome = sobrenome;
        this.sexo = sexo; 
        this.setIdade(idade);
        this.setNumero(numero);
        this.setSalarioMensal(salarioMensal);
        
    }
    
    
    public void setIdade(int idade){
        this.idade = (idade > 0 && idade<150) ? idade : 0;
    }
    
    public void setNumero(int numero){
        this.numero = (numero > 0) ? numero : 0;
    }
    
    public void setSalarioMensal(double salarioMensal){
        this.salarioMensal = (salarioMensal > 0) ? salarioMensal : 0;
    }
    
    public String getNome(){
        return nome;
    }
    
    public String getSobrenome(){
        return sobrenome;
    }
    
    public String getSexo(){
        return sexo;
    }
    
    public int getIdade(){
        return idade;
    }
    
    public int getNumero(){
        return numero;
    }
    
    public double getSalarioMensal(){
        return salarioMensal;
    }
    
}
