/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package a03e01;

/**
 *
 * @author unifvcosta
 */
public class TesteFuncionario {
    
    public static void main(String[] args) {
        Funcionario f1 = new Funcionario();
        Funcionario f2 = new Funcionario("Fulano", "Ciclano", "feminino", 7000, 25, 101);
        
        System.out.printf("F1: Nome:%s, Sobrenome:%s, Sexo:%s, Idade:%d, Numero:%d, Salario Mensal:%.2f\n",
                f1.getNome(), f1.getSobrenome(), f1.getSexo(), f1.getIdade(), f1.getNumero(), f1.getSalarioMensal());
        
        System.out.printf("F2: Nome:%s, Sobrenome:%s, Sexo:%s, Idade:%d, Numero:%d, Salario Mensal:%.2f ",
                f2.getNome(), f2.getSobrenome(), f2.getSexo(), f2.getIdade(), f2.getNumero(), f2.getSalarioMensal());
    }
 
    
}
