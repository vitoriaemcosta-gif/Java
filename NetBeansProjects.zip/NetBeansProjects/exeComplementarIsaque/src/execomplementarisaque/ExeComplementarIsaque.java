/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package execomplementarisaque;

import java.util.Scanner;

/**
 *
 * @author unifvcosta
 */
public class ExeComplementarIsaque {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner input = new Scanner(System.in);
        
        int soma = 0;
        
        System.out.println("Digite X: ");
        int x = input.nextInt();
        System.out.println("Digite Y: ");
        int y = input.nextInt();
        
        for(int i=x; i<= y; i++){
            if (i%3 == 0){
                soma = soma + i;
            }
        
        }
        System.out.println("A soma dos números eh: " + soma);
        
    }
    
}
