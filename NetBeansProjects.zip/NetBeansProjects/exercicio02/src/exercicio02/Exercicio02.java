/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio02;

import java.util.Scanner;

/**
 *
 * @author unifvcosta
 */
public class Exercicio02 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        System.out.println("Digite o primeiro número: ");
        int a = input.nextInt();
        System.out.println("Digite o segundo número: ");
        int b = input.nextInt();
        System.out.println("Digite o terceiro número: ");
        int c = input.nextInt();
        
        System.out.println("a=" + a + ", b=" + b + ", c=" + c );
        // (exemplo) System.out.printf("a=%d, b=%d, c=%d\n", a, b, c);
        
        if (a<b && b<c){
            System.out.println("ABC");
        }
        else if (a<c && c<b){
            System.out.println("ACB");
        }
        else if (b<a && a<c){
            System.out.println("BAC");
        }
        else if (b<c && c<a){
            System.out.println("BCA");
        }
        else if (c<a && a<b){
            System.out.println("CAB");
        }
        else if (c<b && b<a){
            System.out.println("CBA");
        }
            
            // opção
            //if(a>b){
            //int temp = a;
            //a = b;
            //b = temp; }
            //if(b>c){
            //int temp = b;
            //b = c;
            //c = temp; }
            //if(a>b){
            //int temp = a;
            //a = b;
            //b = temp; }
            
    
        // TODO code application logic here
    }
    
}
