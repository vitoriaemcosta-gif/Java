/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exericio03.isaque;

import java.util.Scanner;

/**
 *
 * @author unifvcosta
 */
public class Exericio03Isaque {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        
        String nomeMaisBaixo = "";
        double alturaMaisBaixa = 999.0;
        
        for(int i=0; i<9; i++){
            System.out.println("Digite seu nome: ");
            String nomeAtual = input.next();

            System.out.println("Digite sua altura: ");
            double alturaAtual = input.nextDouble();

            if(alturaAtual < alturaMaisBaixa){
                alturaMaisBaixa = alturaAtual;
                nomeMaisBaixo = nomeAtual;
            }
        }
        
        // int i = 0;
        //while(int i<9){
            //System.out.println("Digite seu nome: ");
            //String nomeAtual = input.next();

            //System.out.println("Digite sua altura: ");
            //double alturaAtual = input.nextDouble();

            //if(alturaAtual < alturaMaisBaixa){
                //alturaMaisBaixa = alturaAtual;
                //nomeMaisBaixo = nomeAtual;
            //}
            
            //i++;
        //}
        
        
        System.out.println("O aluno mais baixo eh, " + nomeMaisBaixo + " e sua altura eh, " + alturaMaisBaixa);
    }
    
}
